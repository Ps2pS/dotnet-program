namespace EmployeeManagement.Services
{
    public interface IEmployeeService
    {
           public System.Object GetUserDetails();
            public IQueryable<Object> FetchUserById(int id);
    }
}