using EmployeeManagement.DTO;
using EmployeeManagement.Models;
namespace EmployeeManagement.Services
{
  public interface IUserService
  {
    public int AddEmployee(AdminViewDto userViewDto);
    Task<List<User>> GetUserDetails();
    Task DeleteUser(int id);
    int EditEmployee(AdminEditDto userViewDto);
    public System.Object FetchAllUserById(int id);
    public ViewModelLogin LoginUser(LoginDto loginDto);
    public int AssignManager(int id, int ManagerId);
    public System.Object GetManagerDetails();
    public System.Object GetEmployeeDetailsOnly();
    public System.Object GetAllUsersDetails();
    string SendMail(string url, string Email);
    bool UserExists(string email);
    string ResetPassword(string Email, string password);





  }
}