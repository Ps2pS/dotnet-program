using EmployeeManagement.Context;
namespace EmployeeManagement.Services
{
    public class EmployeeService : IEmployeeService
    {
        UserDBContext userDbContext;
        public EmployeeService(UserDBContext _userDbContext)
        {
            this.userDbContext = _userDbContext;
        }
        #region Function to search and fetch any particular employee and get selected details
        public IQueryable<Object> FetchUserById(int id)
        {
            var userdata = (from a in userDbContext.Users
                            join b in userDbContext.Professionals on a.UserId equals b.UserId
                            join c in userDbContext.Department on a.UserId equals c.UserId
                            where a.UserId == id
                            select new
                            {
                                FirstName = a.FirstName,
                                LastName = a.LastName,
                                Email = a.Email,
                                PhoneNumber = a.PhoneNumber,
                                Designation = b.Designation,
                                Department = c.departmentName
                            });
            //  if (userdata == null || userdata.Count()==0) {
            //     throw new ArgumentException($"User with ID {id} not found");
            // }
            if (userdata == null || !userdata.Any())
            {
                return null;
            }

            return userdata;
            //return userdata;

        }
        #endregion
        #region Function to  fetch all the employee and get the selected details

        public System.Object GetUserDetails()
        {
            var response = (from a in userDbContext.Users
                            join b in userDbContext.Professionals on a.UserId equals b.UserId
                            join c in userDbContext.Department on a.UserId equals c.UserId
                            select new
                            {
                                FirstName = a.FirstName,
                                LastName = a.LastName,
                                Email = a.Email,
                                PhoneNumber = a.PhoneNumber,
                                Designation = b.Designation,
                                Department = c.departmentName
                            }).ToList();
            if (response == null || !response.Any())
            {
                return null;
            }

            return response;

        }
        #endregion
    }
}