using EmployeeManagement.Context;
using EmployeeManagement.DTO;
using EmployeeManagement.Models;
using FluentValidation;
using Microsoft.EntityFrameworkCore;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace EmployeeManagement.Services
{
  public class UserService : IUserService
  {
     private readonly ISendGridClient _sendGridClient;
        private readonly IConfiguration _config;
    UserDBContext userDbContext;
    public UserService(UserDBContext _userDbContext,ISendGridClient sendGridClient,
       IConfiguration configuration)
    {
      this.userDbContext = _userDbContext;
      _sendGridClient = sendGridClient;
            _config = configuration;
    }
    #region Function to create and add employee data
    int IUserService.AddEmployee(AdminViewDto createUserDto)
    {
      if (userDbContext.Users.Any(U => U.Email == createUserDto.Email))
      {
        throw new ArgumentException($"Email {createUserDto.Email} already exists");
      }
      int id = 0;
      User userPersonal = new User();
      userPersonal.FirstName = createUserDto.FirstName;
      userPersonal.LastName = createUserDto.LastName;
      userPersonal.Email = createUserDto.Email;
      userPersonal.PhoneNumber = createUserDto.PhoneNumber;
      userPersonal.Date_of_Birth = createUserDto.Date_of_Birth;
      userPersonal.Address = createUserDto.Address;
      userPersonal.Password = createUserDto.Password;
      userPersonal.RoleId = createUserDto.RoleId;
      if (userPersonal.RoleId == 1)
      {
        userPersonal.ManagerId = null;
      }
      else
      {
        userPersonal.ManagerId = createUserDto.ManagerId;
      }
      userDbContext.Users.Add(userPersonal);
      userDbContext.SaveChanges();
      id = userPersonal.UserId;
      SaveUserAcademicDetail(createUserDto.userAcademics, id);
      SaveUserProfessionalDetail(createUserDto.userProfessional, id);
      userPersonal.Department = new Department();
      userPersonal.Department.departmentName = createUserDto.departmentName;
      userPersonal.Department.JoinDate = createUserDto.JoinDate;
      userPersonal.Department.Ddesignation = createUserDto.Ddesignation;
      userPersonal.Department.LastDate = createUserDto.LastDate;
      userPersonal.Department.UserId = id;
      userDbContext.Department.Add(userPersonal.Department);
      return userDbContext.SaveChanges();
    }
    #endregion
    #region Function to get each and every record of all the employee
    public async Task<List<User>> GetUserDetails()
    {
      var Userlist = await userDbContext.Users.Include(a => a.userAcademicInfo).Include(p => p.userProfessionalInfo).Include(d => d.Department).Include(r => r.Role).OrderByDescending(u => u.UserId). ToListAsync();
      return Userlist;
    }
    object IUserService.GetAllUsersDetails()
{
    var query = from u in userDbContext.Users
join d in userDbContext.Department on u.UserId equals d.UserId
 join r in userDbContext.Roles on u.RoleId equals r.RoleId
 join a in userDbContext.Academics on u.UserId equals a.UserId
 join p in userDbContext.Professionals on u.UserId equals p.UserId
 orderby u.UserId descending
                select new
                {
                    userId = u.UserId,
                    firstName = u.FirstName,
                    lastName=u.LastName,  
                    email = u.Email,
                    PhoneNumber = u.PhoneNumber,
                    date_of_Birth = u.Date_of_Birth,
                    address = u.Address,
                    managerId = u.ManagerId,
                    password = u.Password,
                    roleId = u.RoleId,
                    isActive=u.isActive
                };

    var subordinates = query.ToList();

    var result = subordinates.Select(sub =>
    {
        var userProfessionalInfo = userDbContext.Professionals
            .Where(p => p.UserId == sub.userId)
            .Select(p => new
            {
              professionalId=p.ProfessionalId,
                companyName = p.CompanyName,
                designation = p.Designation,
                startDate = p.StartDate,
                endDate = p.EndDate,
                userId=p.UserId
            }).ToList();

        var userAcademicInfo = userDbContext.Academics
            .Where(a => a.UserId == sub.userId)
            .Select(a => new
            {
                id=a.Id,
                Qualification = a.Qualification,
                Year = a.Year,
                College = a.College,
                Place = a.Place,
                userId=a.UserId

            }).ToList();

        var department = userDbContext.Department
            .Where(d => d.UserId == sub.userId)
            .Select(d => new
            {
                deptId=d.DeptId,
                userId=d.UserId,
                departmentName = d.departmentName,
                ddesignation = d.Ddesignation,
                joinDate = d.JoinDate,
                lastDate = d.LastDate

            }).FirstOrDefault();
            var Role=userDbContext.Roles.Where(r=>r.RoleId==sub.roleId).Select(r=>new{
              RoleId=r.RoleId,
              UserRole=r.UserRole
            }).FirstOrDefault();

        return new
        {
            sub.managerId,
            sub.userId,
            sub.firstName,
            sub.lastName,
            sub.email,
            sub.PhoneNumber,
            sub.date_of_Birth,
            sub.address,
            sub.password,
            sub.isActive,
            userProfessionalInfo = userProfessionalInfo,
            userAcademicInfo = userAcademicInfo,
            department = department,
            sub.roleId
        };
    }).ToList();

    return result;
}
    #endregion
    #region Function to search and delete any particular employee
       public async Task DeleteUser(int id)
  {
    var value = await userDbContext.Users.FindAsync(id);
    if (value == null) {
          throw new ArgumentException($"User with ID {id} not found");
    }

    var assignedEmployees = await userDbContext.Users.Where(p => p.ManagerId == id).ToListAsync();
    if (assignedEmployees.Count > 0)
    {
        var adminUser = await userDbContext.Users.FirstOrDefaultAsync(u => u.RoleId == 1);
        if (adminUser == null)
    {
    throw new InvalidOperationException("No user with role ID 1 found to reassign assigned employees.");
    }


    foreach (var employee in assignedEmployees)
    {
      employee.ManagerId = adminUser.UserId;
    }
  }
 userDbContext.Users.Remove(value);
 await userDbContext.SaveChangesAsync();
}
    #endregion
    #region Function to edit and update employees data

    int IUserService.EditEmployee(AdminEditDto userViewDto)
    {


      if (userViewDto.userAcademicInfo == null)
      {
        Console.WriteLine("UserAcademic is Null");
      }
      if (userViewDto.userProfessionalInfo == null)
      {
        Console.WriteLine("UserAcademic is Null");
      }
      var userV = userDbContext.Users.SingleOrDefault(t => t.UserId == userViewDto.UserId);
      int id = 0;
      userV.FirstName = userViewDto.FirstName;
      userV.LastName = userViewDto.LastName;
      userV.Email = userViewDto.Email;
      userV.PhoneNumber = userViewDto.PhoneNumber;
      userV.Date_of_Birth = userViewDto.Date_of_Birth;
      userV.Address = userViewDto.Address;
      userV.Password = userViewDto.Password;
      userV.RoleId=userViewDto.RoleId;
      userDbContext.Users.Update(userV);
      userDbContext.SaveChanges();
      id = userV.UserId;
      UpdateUserAcademicDetail(id, userViewDto.userAcademicInfo);
      UpdateUserProfessionalDetail(id, userViewDto.userProfessionalInfo);
      userV.Department = new Department();
      userV.Department = userDbContext.Department.SingleOrDefault(t => t.UserId == id);
      userV.Department.departmentName = userViewDto.departmentName;
      userV.Department.JoinDate = userViewDto.JoinDate;
      userV.Department.Ddesignation = userViewDto.Ddesignation;
      userV.Department.LastDate = userViewDto.LastDate;
      userDbContext.Department.Update(userV.Department);
      return userDbContext.SaveChanges();
    }
    #endregion
    #region Function to search and fetch any particular employee and get all the details
     object IUserService.FetchAllUserById(int id)
    {
        var query = from u in userDbContext.Users
        join d in userDbContext.Department on u.UserId equals d.UserId
        join r in userDbContext.Roles on u.RoleId equals r.RoleId
        join a in userDbContext.Academics on u.UserId equals a.UserId
        join p in userDbContext.Professionals on u.UserId equals p.UserId
        where u.UserId==id
        orderby u.UserId descending
                select new
                {
                    userId = u.UserId,
                    firstName = u.FirstName,
                    lastName=u.LastName,  
                    email = u.Email,
                    PhoneNumber = u.PhoneNumber,
                    date_of_Birth = u.Date_of_Birth,
                    address = u.Address,
                    managerId = u.ManagerId,
                    password = u.Password,
                    roleId = u.RoleId,
                    isActive=u.isActive
                };

    var subordinates = query.ToList();

    var result = subordinates.Select(sub =>
    {
        var userProfessionalInfo = userDbContext.Professionals
            .Where(p => p.UserId == sub.userId)
            .Select(p => new
            {
              professionalId=p.ProfessionalId,
                companyName = p.CompanyName,
                designation = p.Designation,
                startDate = p.StartDate,
                endDate = p.EndDate,
                userId=p.UserId
            }).ToList();

        var userAcademicInfo = userDbContext.Academics
            .Where(a => a.UserId == sub.userId)
            .Select(a => new
            {
                id=a.Id,
                Qualification = a.Qualification,
                Year = a.Year,
                College = a.College,
                Place = a.Place,
                userId=a.UserId

            }).ToList();

        var department = userDbContext.Department
            .Where(d => d.UserId == sub.userId)
            .Select(d => new
            {
                deptId=d.DeptId,
                userId=d.UserId,
                departmentName = d.departmentName,
                ddesignation = d.Ddesignation,
                joinDate = d.JoinDate,
                lastDate = d.LastDate

            }).ToList();

        return new
        {
            sub.managerId,
            sub.userId,
            sub.firstName,
            sub.lastName,
            sub.email,
            sub.PhoneNumber,
            sub.date_of_Birth,
            sub.address,
            sub.password,
            sub.isActive,
            userProfessionalInfo = userProfessionalInfo,
            userAcademicInfo = userAcademicInfo,
            department = department,
            sub.roleId
        };
    }).FirstOrDefault();
    if (result == null)
       {
         throw new ArgumentException($"User with ID {id} not found");
       }

    return result;
}  
  
    #endregion
    #region Function for login for Admin,Employee,Manager
    ViewModelLogin IUserService.LoginUser(LoginDto loginDto)
    {

      var result = userDbContext.Users.Where(t => (t.Email == loginDto.Email && t.Password == loginDto.Password)).FirstOrDefault();
      if (result == null)
      {
        throw new ArgumentException($"Credentials not found");
      }
      else
      {
        ViewModelLogin viewmodel = new ViewModelLogin()
        { UserId = result.UserId, Email = result.Email, FirstName = result.FirstName, RoleId = result.RoleId };

        return viewmodel;

      }
    }
    #endregion
    #region Function to assign manager to employee
    public int AssignManager(int id, int ManagerId)
    {
      if (userDbContext.Users.Count() > 0)
      {
        User user = userDbContext.Users.FirstOrDefault(a => a.UserId == id);
        user.ManagerId = ManagerId;
        user.isActive=true;
        userDbContext.Update(user);
        userDbContext.SaveChanges();
      }
      return 1;
    }
    #endregion
    #region Function to add and save employees multiple Professiional details
    private void SaveUserProfessionalDetail(ICollection<UserProfessionalDetailDto> userProfessionalDetails, int userId)
    {

      foreach (var item in userProfessionalDetails)
      {
        ProfessionalInfo professional = new ProfessionalInfo();
        professional.CompanyName = item.CompanyName;
        professional.Designation = item.Designation;
        //professional.StartDate = item.StartDate;
        //professional.EndDate = item.EndDate;
        professional.UserId = userId;
        professional.ProfessionalId = item.ProfessionalId;
        userDbContext.Professionals.Add(professional);
        userDbContext.SaveChanges();
      }
    }
    #endregion
    #region Function to add and save employees multiple Academic details
    private void SaveUserAcademicDetail(ICollection<UserAcademicDto> userAcademicDetails, int userId)
    {
      try
      {

        foreach (var item1 in userAcademicDetails)
        {
          AcademicInfo academicInfo = new AcademicInfo();
          academicInfo.Qualification = item1.Qualification;
          academicInfo.Year = item1.Year;
          academicInfo.College = item1.College;
          academicInfo.Place = item1.Place;
          academicInfo.UserId = userId;
          academicInfo.Id = item1.Id;
          userDbContext.Academics.Add(academicInfo);
          userDbContext.SaveChanges();
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }
    #endregion
    #region Function to Update and save employees multiple Employee Academic details
    private void UpdateUserAcademicDetail(int userId, ICollection<UserAcademicDto> userAcademicDetails)
    {
      foreach (var item1 in userAcademicDetails)
      {
        if (item1.Id > 0)
        {
          AcademicInfo academicInfo = userDbContext.Academics.SingleOrDefault(t => t.UserId == userId && t.Id == item1.Id);
          academicInfo.Qualification = item1.Qualification;
          academicInfo.Year = item1.Year;
          academicInfo.College = item1.College;
          academicInfo.Place = item1.Place;
          academicInfo.UserId = userId;
          academicInfo.Id=item1.Id;
          userDbContext.Academics.Update(academicInfo);
          userDbContext.SaveChanges();
        }
        else
        {
          AcademicInfo academicInfo = new AcademicInfo();
          academicInfo.Qualification = item1.Qualification;
          academicInfo.Year = item1.Year;
          academicInfo.College = item1.College;
          academicInfo.Place = item1.Place;
          academicInfo.UserId = userId;
          academicInfo.Id=item1.Id;

          userDbContext.Academics.Add(academicInfo);
          userDbContext.SaveChanges();
        }

      }
    }
    #endregion
    #region Function to add and save employees multiple  Employee Professional details
    private void UpdateUserProfessionalDetail(int userId, ICollection<UserProfessionalDetailDto> userProfessionalDetails)
    {

      foreach (var item1 in userProfessionalDetails)
      {
        if (item1.ProfessionalId > 0)
        {
          ProfessionalInfo professional = userDbContext.Professionals.SingleOrDefault(t => t.UserId == userId && t.ProfessionalId == item1.ProfessionalId);////
          professional.CompanyName = item1.CompanyName;
          professional.Designation = item1.Designation;
          //professional.StartDate = item1.StartDate;
          //professional.EndDate = item1.EndDate;
          professional.UserId = userId;
          professional.ProfessionalId=item1.ProfessionalId;
          userDbContext.Professionals.Update(professional);
          userDbContext.SaveChanges();
        }
        else
        {

          ProfessionalInfo professional = new ProfessionalInfo();
          professional.CompanyName = item1.CompanyName;
          professional.Designation = item1.Designation;
          //professional.StartDate = item1.StartDate;
          //professional.EndDate = item1.EndDate;
          professional.UserId = userId;
          professional.ProfessionalId=item1.ProfessionalId;
          userDbContext.Professionals.Add(professional);
          userDbContext.SaveChanges();
        }

      }
    }
    #endregion
    public System.Object GetManagerDetails()
    {
      var response = (from a in userDbContext.Users
                      join b in userDbContext.Professionals on a.UserId equals b.UserId
                      join c in userDbContext.Department on a.UserId equals c.UserId
                      where a.RoleId == 3
                      select new
                      {
                        UserId = a.UserId,
                        FirstName = a.FirstName,
                        LastName = a.LastName,
                        Email = a.Email,
                        PhoneNumber = a.PhoneNumber,
                        Designation = b.Designation,
                        Department = c.departmentName
                      }).ToList();
      return response;
    }

    public System.Object GetEmployeeDetailsOnly()
    {
      var response = (from a in userDbContext.Users
                      join b in userDbContext.Professionals on a.UserId equals b.UserId
                      join c in userDbContext.Department on a.UserId equals c.UserId
                      where a.RoleId == 2 && a.isActive==false
                      select new
                      {
                        UserId = a.UserId,
                        FirstName = a.FirstName,
                        LastName = a.LastName,
                        Email = a.Email,
                        PhoneNumber = a.PhoneNumber,
                        Designation = b.Designation,
                        Department = c.departmentName
                      }).ToList();
      return response;
    }
     public string SendMail(string url, string Email)
        {

            string fromEmail = _config.GetSection("EmailSettings").GetValue<string>("SenderEmail");
            string fromName = _config.GetSection("EmailSettings").GetValue<string>("SenderName");
            string apk = _config.GetSection("EmailSettings").GetValue<string>("ApiKey");
            var msg = new SendGridMessage()
            {
                From = new EmailAddress(fromEmail, fromName),
                Subject = "Reset Link",
                PlainTextContent = url
            };
            msg.AddTo(Email);
            var response = _sendGridClient.SendEmailAsync(msg);
            return "send successfully";

            
        }

        public bool UserExists(string email)
        {
            if (userDbContext.Users.Any(x => x.Email == email))
                return true;
            return false;
        }

        public string ResetPassword(string email, string password)
        {
            ResetPassword reset = new ResetPassword();
            reset.Email = email;
            reset.password = password;

            var user = userDbContext.Users.FirstOrDefault(t => t.Email == email);
            reset.Email = user.Email;

            if (UserExists(email))
            {
                user.Password = password;
                userDbContext.Users.Update(user);
                userDbContext.SaveChanges();
                return "Password Changed Successfully";
            }
            else
                return "Enter valid Email!!!";
        }

    }
  }

