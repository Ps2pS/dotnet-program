namespace EmployeeManagement.Services
{
    public interface IManagerService
    {
        public System.Object GetSubordinatesDetails(int ManagerId);
        public System.Object GetUserDetails();
        public IQueryable<Object> FetchUserById(int id);
    }
}