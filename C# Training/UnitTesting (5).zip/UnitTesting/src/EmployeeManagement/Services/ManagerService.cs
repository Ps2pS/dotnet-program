using EmployeeManagement.Context;
namespace EmployeeManagement.Services
{
  public class ManagerService : IManagerService
  {
    UserDBContext userDbContext;
    public ManagerService(UserDBContext _userDbContext)
    {
      this.userDbContext = _userDbContext;

    }
    #region Function to search and fetch employee under that manager and get all the details
   
object IManagerService.GetSubordinatesDetails(int ManagerId)
{
    var query = from e in userDbContext.Users
                join m in userDbContext.Users on e.ManagerId equals m.UserId
                where m.UserId == ManagerId
                orderby e.UserId
                select new
                {
                    EmployeeId = e.UserId,
                    EmployeeName = e.FirstName + " " + e.LastName,
                    ManagerId = e.ManagerId,
                    ManagerName = m.FirstName + " " + m.LastName,
                    UserId = e.UserId,
                    FirstName = e.FirstName,
                    LastName = e.LastName,
                    Email = e.Email,
                    PhoneNumber = e.PhoneNumber,
                    Date_of_Birth = e.Date_of_Birth,
                    Address = e.Address,
                    Password = e.Password,
                    RoleId = e.RoleId,
                    isActive=e.isActive
                };

    var subordinates = query.ToList();

    var result = subordinates.Select(sub =>
    {
        var professionalDetails = userDbContext.Professionals
            .Where(p => p.UserId == sub.UserId)
            .Select(p => new
            {
                CompanyName = p.CompanyName,
                Designation = p.Designation,
                StartDate = p.StartDate,
                EndDate = p.EndDate
            }).ToList();

        var academicDetails = userDbContext.Academics
            .Where(a => a.UserId == sub.UserId)
            .Select(a => new
            {
                Qualification = a.Qualification,
                Year = a.Year,
                College = a.College,
                Place = a.Place
            }).ToList();

        var departmentDetails = userDbContext.Department
            .Where(d => d.UserId == sub.UserId)
            .Select(d => new
            {
                DepartmentName = d.departmentName,
                DepartmentDesignation = d.Ddesignation,
                JoinDate = d.JoinDate,
                LastDate = d.LastDate
            }).ToList();

        return new
        {
            sub.EmployeeId,
            sub.EmployeeName,
            sub.ManagerId,
            sub.ManagerName,
            sub.UserId,
            sub.FirstName,
            sub.LastName,
            sub.Email,
            sub.PhoneNumber,
            sub.Date_of_Birth,
            sub.Address,
            sub.Password,
            sub.isActive,
            ProfessionalDetails = professionalDetails,
            AcademicDetails = academicDetails,
            DepartmentDetails = departmentDetails,
            sub.RoleId
        };
    }).ToList();

    return result;
}

    #endregion
    #region Function to search and fetch any particular employee and get the selected  details
    public IQueryable<Object> FetchUserById(int id)
    {
      var userdata = (from a in userDbContext.Users
                      join b in userDbContext.Professionals on a.UserId equals b.UserId
                      join c in userDbContext.Department on a.UserId equals c.UserId
                      where a.UserId == id
                      select new
                      {
                        FirstName = a.FirstName,
                        LastName = a.LastName,
                        Email = a.Email,
                        PhoneNumber = a.PhoneNumber,
                        Designation = b.Designation,
                        Department = c.departmentName
                      });
      return userdata;

    }
    #endregion
    #region Function to fetch all the employee and get the selected details
    public System.Object GetUserDetails()
    {
      var response = (from a in userDbContext.Users
                      join b in userDbContext.Professionals on a.UserId equals b.UserId
                      join c in userDbContext.Department on a.UserId equals c.UserId
                      select new
                      {
                        FirstName = a.FirstName,
                        LastName = a.LastName,
                        Email = a.Email,
                        PhoneNumber = a.PhoneNumber,
                        Designation = b.Designation,
                        Department = c.departmentName
                      }).ToList();
      return response;

    }
     #endregion

  }
}