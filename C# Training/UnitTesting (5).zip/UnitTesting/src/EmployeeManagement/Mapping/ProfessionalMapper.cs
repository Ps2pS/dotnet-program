using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace EmployeeManagement.Mapping
{
    public class ProfessionalMapper
    {
        public ProfessionalMapper(EntityTypeBuilder<ProfessionalInfo> entityBuilder)
        {
             entityBuilder.HasKey(t => t.ProfessionalId);
             entityBuilder.HasOne(t => t.userPersonalInfos).WithMany(u => u.userProfessionalInfo).HasForeignKey(x => x.UserId);
              
    }
    }
}