using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace EmployeeManagement.Mapping
{
    public class AcademicMapper
    {
        public AcademicMapper(EntityTypeBuilder<AcademicInfo> entityBuilder)
        {
             entityBuilder.HasKey(t => t.Id);
            entityBuilder.Property(t => t.Qualification).IsRequired(); 
            entityBuilder.Property(t => t.Year).IsRequired();
            entityBuilder.Property(t => t.College).IsRequired();
            entityBuilder.Property(t => t.Place).IsRequired();  
             entityBuilder.HasOne(t => t.userPersonalInfos).WithMany(u => u.userAcademicInfo).HasForeignKey(x => x.UserId);          
        }
    }
}