using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace EmployeeManagement.Mapping
{
    public class RoleMapper
    {
        public RoleMapper(EntityTypeBuilder<Role> builder)
        {        
        {
             builder.HasAlternateKey(t => t.UserRole);
                builder.HasKey(x => x.RoleId);    
        }
    }
    }
}