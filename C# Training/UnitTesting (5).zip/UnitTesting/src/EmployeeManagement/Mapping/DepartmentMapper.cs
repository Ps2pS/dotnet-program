using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace EmployeeManagement.Mapping
{
  public class DepartmentMapper
  {
    public DepartmentMapper(EntityTypeBuilder<Department> entityBuilder)
    {
      entityBuilder.HasKey(t => t.DeptId);

      entityBuilder.Property(t => t.JoinDate).IsRequired();
      entityBuilder.HasOne(t => t.UserPersonal).WithOne(u => u.Department);
    }
  }
}