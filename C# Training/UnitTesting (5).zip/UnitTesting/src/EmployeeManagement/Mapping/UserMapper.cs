using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace EmployeeManagement.Mapping
{
    public class UserMapper
    {
        public UserMapper(EntityTypeBuilder<User> entityBuilder)
        {    
            entityBuilder.HasKey(t => t.UserId);
            entityBuilder.Property(t => t.FirstName).IsRequired();
            entityBuilder.Property(t => t.LastName).IsRequired();
            entityBuilder.Property(t => t.Email).IsRequired();
            entityBuilder.Property(t => t.PhoneNumber).IsRequired();
            entityBuilder.Property(t => t.Date_of_Birth).IsRequired();
            entityBuilder.Property(t => t.Address).IsRequired();
            entityBuilder.Property(t => t.Password).IsRequired();
    }
            
        }
    }