using Microsoft.AspNetCore.Mvc;
using EmployeeManagement.Services;

namespace EmployeeManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ManagerController : ControllerBase
    {
        IManagerService imanagerService;
        public ManagerController(IManagerService _imanagerService)
        {
            this.imanagerService = _imanagerService;
        }
        #region get employee detail under that manager
        [HttpGet("subordinate/get")]
        public IActionResult UserDetails(int ManagerId)
        {
            if (ManagerId <= 0)
            {
                return BadRequest("Please input valid Id");
            }
            else

                return Ok(imanagerService.GetSubordinatesDetails(ManagerId));
        }
        #endregion
        #region view all user basic details
        [HttpGet]
        [Route("user/view")]
        public IActionResult FetchUser()
        {
            return Ok(imanagerService.GetUserDetails());
        }
        #endregion
        #region search user basis details by their id
        [HttpGet]
        [Route("user/view/{id}")]
        public IActionResult GetUserById(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Please input valid Id");
            }
            var user = imanagerService.FetchUserById(id);
            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }
        #endregion
    }
}