using EmployeeManagement.DTO;
using EmployeeManagement.Services;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
namespace EmployeeManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        IEmployeeService iemployeeService;
         private readonly IValidator<AdminViewDto> validator;
        public EmployeeController(IEmployeeService _iemployeeService,IValidator<AdminViewDto> _validator)
        {
            this.iemployeeService = _iemployeeService;
            this.validator=_validator;
        }
        #region ViewUser
        [HttpGet]
        [Route("user/view")]
       public IActionResult FetchUser()
{
    try
    {
        var userDetails = iemployeeService.GetUserDetails();
        if (userDetails == null)
        {
            return NotFound("No user details found.");
        }
        else
        {
            return Ok(userDetails);
        }
    }
    catch (Exception ex)
    {
        return StatusCode(500, ex.Message);
    }
}
        #endregion
        #region SearchUser
        [HttpGet]
        [Route("user/search/{id}")]
      public IActionResult GetUserById(int id)
{
    try
    {
        if(id<=0){
            return BadRequest();
        }
        var userDetails = iemployeeService.FetchUserById(id);
        if (userDetails == null)
        {
            return NotFound("User not found.");
        }

        if (!userDetails.Any())
        {
            return NotFound("User not found.");
        }
        
        return Ok(userDetails);
    }
    catch (Exception ex)
    {
        return StatusCode(500, ex.Message);
    }
}
        #endregion
    }
}