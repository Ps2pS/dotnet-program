using Microsoft.AspNetCore.Mvc;
using EmployeeManagement.Services;
using EmployeeManagement.DTO;
using FluentValidation;
using FluentValidation.Results;
namespace EmployeeManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        IUserService iuserService;
        private readonly IValidator<AdminViewDto> validator;
        private readonly IValidator<List<UserAcademicDto>> aValidator;
        public AdminController(IUserService _iuserService, IValidator<AdminViewDto> _validator, IValidator<List<UserAcademicDto>> _aValidator)
        {
            this.iuserService = _iuserService;
            this.validator = _validator;
            this.aValidator = _aValidator;
        }
        #region CreatePost
        [HttpPost("user/create")]
        public IActionResult CreateUser([FromBody] AdminViewDto viewModel)
        {
            try
            {
                ValidationResult result = validator.Validate(viewModel);
                ValidationResult result2 = aValidator.Validate(viewModel.userAcademics.ToList());
                if (result.IsValid && result2.IsValid)
                {
                    return Ok(iuserService.AddEmployee(viewModel));
                }
                else
                {
                    return BadRequest(result.Errors);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

        }
        #endregion
        #region GetAllUserDetails
        [HttpGet("users/get")]
        public async Task<IActionResult> UserDetails()
        {
            try
            {
                var userDetails = await iuserService.GetUserDetails();

                if (userDetails == null)
                {
                    return NotFound();
                }

                return Ok(userDetails);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("users/get/all")]
        public IActionResult UserAllDetails()
        {
            try
            {
                var userDetails = iuserService.GetAllUsersDetails();

                if (userDetails == null)
                {
                    return NotFound();
                }

                return Ok(userDetails);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        #endregion
        #region DeleteUserById
        [HttpDelete("delete/user/{id}")]
        public async Task<IActionResult> DeleteContact(int id)
        {
            if (id <= 0)
            {
                return BadRequest();
            }
            await iuserService.DeleteUser(id);
            return Ok();

        }
        #endregion
        #region Update or Edit User
        [HttpPut("user/update")]

        public IActionResult UpdateUserData(AdminEditDto userViewDto)
        {
            var updatedUser = iuserService.EditEmployee(userViewDto);

            if (updatedUser == 0)
            {
                return BadRequest();
            }

            return Ok();
        }
        [HttpGet("user/get/{id}")]
       public IActionResult FetchAllUserById(int id)
{
    try
    {
        if (id <= 0)
        {
            return BadRequest();
        }

        var user = iuserService.FetchAllUserById(id);

        if (user == null)
        {
            return NotFound();
        }

        return Ok(user);
    }
    catch (Exception ex)
    {
        return StatusCode(404, ex.Message);
    }
}
        #endregion
        #region Login
         [HttpPost]
        [Route("user/login")]
       public IActionResult UserLoginPage([FromBody] LoginDto userLogin)
{
    try
    {
        var result = iuserService.LoginUser(userLogin);

        if (result!=null)
        {
            return Ok(result);
        }
        else
        {
            return BadRequest("Invalid login credentials.");
        }
    }
    catch (Exception ex)
    {
        return StatusCode(401, ex.Message);
    }
}
        #endregion
        #region Update manager of any user
        [HttpPut("manager/update/{id}/{ManagerId}")]
        public IActionResult UpdateManagerData(int id, int ManagerId)
        {


            return Ok(iuserService.AssignManager(id, ManagerId));

        }
        #endregion
        #region view all user basic details
        [HttpGet]
        [Route("user/view/manager")]
        public IActionResult GetManagerDetails()
        {
            return Ok(iuserService.GetManagerDetails());
        }
        #endregion
        [HttpGet]
        [Route("user/view/employeeonly")]
        public IActionResult GetEmployeeDetails()
        {
            return Ok(iuserService.GetEmployeeDetailsOnly());
        }

        [HttpPost("ResetPassword")]
        public IActionResult ResetPassword(ResetPassword resetPassword)
        {
            var userLoginData = iuserService.ResetPassword(resetPassword.Email, resetPassword.password);
            return Ok(userLoginData);
        }
        [HttpGet("sendResetLink")]
        public bool sendResetLink(string Email)
        {
            var userFromRepo = iuserService.UserExists(Email);
            if (userFromRepo == false)
                return false;
            else
            {
                var Url = "http://localhost:4200/ResetPassword";
                iuserService.SendMail(Url, Email);
                return true;
            }
        }

    }
}