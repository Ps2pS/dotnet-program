using EmployeeManagement.Context;
using EmployeeManagement.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using EmployeeManagement.DTO;
using FluentValidation;
using EmployeeManagement.DTO.DTOValidation;
using SendGrid.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddDbContext<UserDBContext>(t => t.UseNpgsql(builder.Configuration.GetConnectionString("dbConnection")));
builder.Services.AddTransient<IUserService, UserService>();
builder.Services.AddTransient<IEmployeeService, EmployeeService>();
builder.Services.AddTransient<IManagerService, ManagerService>();
builder.Services.AddSendGrid(options =>
{
    options.ApiKey = builder.Configuration.GetSection("EmailSettings").GetValue<string>("ApiKey");
});
builder.Services.AddCors();

builder.Services.AddScoped<IValidator<AdminViewDto>, AdminViewModelValidation>(); // doing IOC of Ivalidator
builder.Services.AddScoped<IValidator<List<UserAcademicDto>> , UserAcademicDetailValidation>();

builder.Services.AddValidatorsFromAssemblyContaining<AdminViewModelValidation>();
builder.Services.AddControllersWithViews().AddNewtonsoftJson(options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c => c.MapType<DateOnly>(() => new OpenApiSchema
{
    Type = "string",
    Format = "date"
}));
builder.Services.AddControllers().AddJsonOptions(x =>
{
    // serialize DateOnly as strings
x.JsonSerializerOptions.Converters.Add(new DateOnlyJsonConverter());
x.JsonSerializerOptions.Converters.Add(new NullableDateOnlyJsonConverter());
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseCors(x => x.AllowAnyMethod().AllowAnyHeader()
.SetIsOriginAllowed(origin => true).AllowCredentials());

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
