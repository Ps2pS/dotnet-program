using Microsoft.EntityFrameworkCore;
using EmployeeManagement.Models;
using EmployeeManagement.Mapping;

namespace EmployeeManagement.Context
{
    public class UserDBContext : DbContext
    {
        public UserDBContext(DbContextOptions dbContextOptions) : base(dbContextOptions)
        {

        }
        public DbSet<User> Users { get; set; }
        public DbSet<AcademicInfo> Academics { get; set; }
        public DbSet<ProfessionalInfo> Professionals { get; set; }
        public DbSet<Department> Department { get; set; }
        public DbSet<Role> Roles { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            new UserMapper(modelBuilder.Entity<User>());
            new ProfessionalMapper(modelBuilder.Entity<ProfessionalInfo>());
            new AcademicMapper(modelBuilder.Entity<AcademicInfo>());
            new DepartmentMapper(modelBuilder.Entity<Department>());
            new RoleMapper(modelBuilder.Entity<Role>());
            modelBuilder.Entity<Role>().HasData(
           new { RoleId = 1, UserRole = "Admin" },
           new { RoleId = 2, UserRole = "Employee" }, 
            new { RoleId = 3, UserRole = "Manager" }
       );


        }
    }

}