using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.DTO
{
    public class UserProfessionalDetailDto
    {
         public string? CompanyName { get; set; }

        public string? Designation { get; set; }

       // public DateOnly StartDate { get; set; }

       // public DateOnly EndDate { get; set; }
        public int ProfessionalId{get;set;}
    }
}