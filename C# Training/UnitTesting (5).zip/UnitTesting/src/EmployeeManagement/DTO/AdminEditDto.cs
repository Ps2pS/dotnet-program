namespace EmployeeManagement.DTO
{
    public class AdminEditDto
    {
        #region Personal
        public int? UserId{get;set;}
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string ?PhoneNumber { get; set; }
        public DateOnly Date_of_Birth { get; set; }
        public string? Address { get; set; }
        public string? Password { get; set; }
        public int? ManagerId { get; set; }
        #endregion
        #region Professional
       public ICollection<UserProfessionalDetailDto> ?userProfessionalInfo{get;set;}
        #endregion
        #region Qualifications
       public ICollection<UserAcademicDto> ?userAcademicInfo{get;set;}
        #endregion
        #region Department
        public string? departmentName { get; set; }
        public string? Ddesignation { get; set; }
        public DateOnly JoinDate { get; set; }
        public DateOnly LastDate { get; set; }
        #endregion
        #region Role
        public int RoleId { get; set; }
        #endregion

    }




}