using FluentValidation;
namespace EmployeeManagement.DTO.DTOValidation
{
    public class AdminViewModelValidation : AbstractValidator<AdminViewDto>
    {
        public AdminViewModelValidation()
        {

            RuleFor(x => x.Email).EmailAddress().WithMessage("please enter valid email");
            RuleFor(x => x.FirstName).NotEmpty().WithMessage("please enter valid name");
            RuleFor(x => x.LastName).NotEmpty().WithMessage("please enter valid name");   
            RuleFor(x => x.Date_of_Birth).NotEmpty();
            RuleFor(x => x.PhoneNumber).Length(10);
            RuleFor(x => x.Password).NotEmpty();
            

        }
    }
}
