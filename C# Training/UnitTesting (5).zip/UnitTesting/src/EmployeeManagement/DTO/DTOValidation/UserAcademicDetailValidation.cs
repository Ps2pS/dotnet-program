using FluentValidation;

namespace EmployeeManagement.DTO.DTOValidation
{
    public class UserAcademicDetailValidation : AbstractValidator<List<UserAcademicDto>>
    {
        public UserAcademicDetailValidation()
        {
            
                
            
            RuleFor(x => x.Select(y=>y.Qualification)).NotEmpty().WithMessage("please enter valid Degree"); ;
             RuleFor(x => x.Select(y=>y.Place)).NotEmpty().WithMessage("please enter valid College name"); ;
             RuleFor(x => x.Select(y=>y.Year)).NotEmpty().WithMessage("please enter valid year");
             RuleFor(x=> x.Select(y=>y.College)).NotEmpty().WithMessage("please enter valid place"); 
        }

    }
}