using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.DTO
{
    public class ViewModelLogin
    {
         public string ?Email{get;set;}
         public string ?FirstName{get;set;}
         public int RoleId{get;set;}
         public string ?UserRole{get;set;}
         public int ?UserId{get;set;}
    }
}