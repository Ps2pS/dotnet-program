using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.DTO
{
    public class ResetPassword
    {
        public string ?Email{get;set;}
        public string? password{get;set;}
    }
}