namespace EmployeeManagement.DTO
{
    public class UserAcademicDto
    {
         public string? Qualification { get; set; }

        public int Year { get; set; }

        public string? College { get; set; }

        public string? Place { get; set; }
        public int Id { get; set; }
    }
}