using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.Models
{
    public class ProfessionalInfo
    {
        [Key]
         public int ProfessionalId { get; set; }
       
        public string? CompanyName { get; set; }
        
        public string? Designation { get; set; }  
        public DateOnly StartDate { get; set; }  
        public DateOnly EndDate { get; set; }
        public int UserId { get; set; }
        public virtual User? userPersonalInfos{get;set;}
    }
}