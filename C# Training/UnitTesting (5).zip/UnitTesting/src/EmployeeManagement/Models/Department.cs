using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.Models
{
      public class Department
    {
        [Key]
        public int DeptId { get; set; }
        public int UserId{get;set;}
        public string ?departmentName{get;set;}
        public string? Ddesignation { get; set; } 
        public DateOnly JoinDate { get; set; }
        public DateOnly LastDate { get; set; }
        public virtual User?UserPersonal { get; set; }
    }
        
}