using System.ComponentModel.DataAnnotations;
namespace EmployeeManagement.Models
{
    public class AcademicInfo
    {
    [Key]
    public int Id { get; set; }
    public int UserId { get; set; } 
    public string? Qualification { get; set; }
    public int Year { get; set; }
    public string? College { get; set; }
    public string? Place { get; set; }
    public virtual User? userPersonalInfos{get;set;}
    }
}