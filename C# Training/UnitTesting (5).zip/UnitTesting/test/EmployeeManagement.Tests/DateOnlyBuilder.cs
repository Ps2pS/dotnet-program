using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoFixture;
using AutoFixture.Kernel;

namespace EmployeeManagement.Tests
{
   public class DateOnlyBuilder : ISpecimenBuilder
{
    public object Create(object request, ISpecimenContext context)
    {
        var type = request as Type;
        if (type == typeof(DateOnly))
        {
            // Generate a valid DateOnly value for testing purposes
            return new DateOnly(context.Create<DateTime>().Year, context.Create<DateTime>().Month, context.Create<DateTime>().Day);
        }

        return new NoSpecimen();
    }
}

}