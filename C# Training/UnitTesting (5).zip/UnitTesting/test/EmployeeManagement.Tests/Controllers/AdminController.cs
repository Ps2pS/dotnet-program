namespace EmployeeManagement.Tests;
using Xunit;
using EmployeeManagement.Controllers;
using EmployeeManagement.DTO;
using EmployeeManagement.Services;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoFixture;
using FluentValidation.Results;
using EmployeeManagement.Models;

public class AdminControllers : BaseFactoryClass
{
    private Mock<IUserService> userService;
    private Mock<IValidator<AdminViewDto>> validatorMock;
    private Mock<IValidator<List<UserAcademicDto>>> validatorMock2;
    private AdminController controller;
    private Fixture fixture;
    public AdminControllers()
    {
        userService = new Mock<IUserService>();
        validatorMock = new Mock<IValidator<AdminViewDto>>();
        validatorMock2 = new Mock<IValidator<List<UserAcademicDto>>>();
        controller = new AdminController(userService.Object, validatorMock.Object, validatorMock2.Object);
        fixture = new Fixture();
    }
    [Fact]
    public void CreateUser_ValidData_ReturnsOkResult()
    {
        // Arrange
        var viewModel = CreateEmployeeData();
        var validationResult = new FluentValidation.Results.ValidationResult();
        validatorMock.Setup(v => v.Validate(viewModel)).Returns(validationResult);
        var academicValidationResult = new FluentValidation.Results.ValidationResult();
        validatorMock2.Setup(v => v.Validate(It.IsAny<List<UserAcademicDto>>())).Returns(academicValidationResult);
        userService.Setup(u => u.AddEmployee(viewModel)).Returns(1);
        // Act
        var result = controller.CreateUser(viewModel);
        // Assert
        Assert.IsType<OkObjectResult>(result);
    }
    [Fact]
    public void CreateUser_InvalidData_ReturnsBadRequestResult()
    {
        // Arrange
        var viewModel = CreateEmployeeData();
        var validationResult = new FluentValidation.Results.ValidationResult();
        validationResult.Errors.Add(new ValidationFailure("propertyName", "Error message"));
        validatorMock.Setup(v => v.Validate(viewModel)).Returns(validationResult);
        var academicValidationResult = new FluentValidation.Results.ValidationResult();
        validatorMock2.Setup(v => v.Validate(It.IsAny<List<UserAcademicDto>>())).Returns(academicValidationResult);
        userService.Setup(u => u.AddEmployee(viewModel)).Returns(0);
        // Act
        var result = controller.CreateUser(viewModel);
        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.IsAssignableFrom<List<ValidationFailure>>(badRequestResult.Value);
    }
    [Fact]
    public void UserAllDetails_UserDetailsNotNull_ReturnsOkResult()
    {
        // Arrange
        var userDetails = new List<User>();
        userService.Setup(u => u.GetAllUsersDetails()).Returns(userDetails);
        // Act
        var result = controller.UserAllDetails();
        // Assert
        Assert.IsType<OkObjectResult>(result);
    }
    [Fact]
    public void UserAllDetails_UserDetailsNull_ReturnsNotFoundResult()
    {
        // Arrange
        userService.Setup(u => u.GetAllUsersDetails()).Returns((List<User>)null);
        // Act
        var result = controller.UserAllDetails();
        // Assert
        Assert.IsType<NotFoundResult>(result);
    }
    [Fact]
    public async Task DeleteContact_ValidId_ReturnsOkResult()
    {
        // Arrange
        int id = 1;
        userService.Setup(u => u.DeleteUser(id)).Returns(Task.CompletedTask);
        // Act
        var result = await controller.DeleteContact(id);
        // Assert
        Assert.IsType<OkResult>(result);
    }
    [Fact]
    public async Task DeleteContact_InvalidId_ReturnsBadRequestResult()
    {
        // Arrange
        int id = 0;
        userService.Setup(u => u.DeleteUser(id)).Returns(Task.CompletedTask);
        // Act
        var result = await controller.DeleteContact(id);
        // Assert
        Assert.IsType<BadRequestResult>(result);
    }
    [Fact]
    public void UpdateUserData_UpdateSuccessful_ReturnsOkResult()
    {
        // Arrange
        var userViewDto = new AdminEditDto();
        userService.Setup(u => u.EditEmployee(userViewDto)).Returns(1);
        // Act
        var result = controller.UpdateUserData(userViewDto);
        // Assert
        Assert.IsType<OkResult>(result);
    }
    [Fact]
    public void UpdateUserData_UpdateFailed_ReturnsBadRequestResult()
    {
        // Arrange
        var userViewDto = new AdminEditDto();
        userService.Setup(u => u.EditEmployee(userViewDto)).Returns(0);
        // Act
        var result = controller.UpdateUserData(userViewDto);
        // Assert
        Assert.IsType<BadRequestResult>(result);
    }
    [Fact]
    public void FetchAllUserById_ValidId_ReturnsOkResult()
    {
        // Arrange
        int id = 1;
        var user = new User();
        userService.Setup(u => u.FetchAllUserById(id)).Returns(user);
        // Act
        var result = controller.FetchAllUserById(id);
        // Assert
        Assert.IsType<OkObjectResult>(result);
    }
    [Fact]
    public void FetchAllUserById_InvalidId_ReturnsBadRequestResult()
    {
        // Arrange
        int id = 0;
        // Act
        var result = controller.FetchAllUserById(id);
        // Assert
        Assert.IsType<BadRequestResult>(result);
    }
    [Fact]
    public void FetchAllUserById_IdNotFound_ReturnsNotFoundResult()
    {
        // Arrange
        int id = 1000;
        userService.Setup(u => u.FetchAllUserById(id)).Returns((User)null);
        // Act
        var result = controller.FetchAllUserById(id);
        // Assert
        Assert.IsType<NotFoundResult>(result);
    }
    [Fact]
    public void UserLoginPage_ValidLogin_ReturnsOkResult()
    {
        // Arrange
        var validLoginDto = fixture.Create<LoginDto>();
        var validViewModel = fixture.Create<ViewModelLogin>();
        userService.Setup(u => u.LoginUser(validLoginDto)).Returns(validViewModel);
        // Act
        var result = controller.UserLoginPage(validLoginDto);
        // Assert
        Assert.IsType<OkObjectResult>(result);
        var okResult = (OkObjectResult)result;
        Assert.Equal(validViewModel, okResult.Value);
    }
    [Fact]
    public void UserLoginPage_InvalidLogin_ReturnsBadRequestResult()
    {
        // Arrange
        var invalidLoginDto = fixture.Create<LoginDto>();
        userService.Setup(u => u.LoginUser(invalidLoginDto)).Returns((ViewModelLogin)null);
        // Act
        var result = controller.UserLoginPage(invalidLoginDto);
        // Assert
        Assert.IsType<BadRequestObjectResult>(result);
        var badRequestResult = (BadRequestObjectResult)result;
        Assert.Equal("Invalid login credentials.", badRequestResult.Value);
    }
}