using AutoFixture;
using EmployeeManagement.Controllers;
using EmployeeManagement.DTO;
using EmployeeManagement.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace EmployeeManagement.Tests
{
    public class ManagerControllers : BaseFactoryClass
    {
        private readonly Fixture fixture;
        private readonly Mock<IManagerService> managerServiceMock;
        private readonly ManagerController managerController;
        public ManagerControllers()
        {
            fixture = new Fixture();
            managerServiceMock = new Mock<IManagerService>();
            managerController = new ManagerController(managerServiceMock.Object);
        }
        [Fact]
        public void UserDetails_ValidManagerId_ReturnsOkResult()
        {
            // Arrange
            int managerId = 123;
            var expectedSubordinates = GetEmployeeData();

            managerServiceMock
                .Setup(s => s.GetSubordinatesDetails(managerId))
                .Returns(expectedSubordinates);
            // Act
            var result = managerController.UserDetails(managerId);
            // Assert
            Assert.IsType<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.Equal(expectedSubordinates, okResult.Value);
            managerServiceMock.Verify(s => s.GetSubordinatesDetails(managerId), Times.Once);
        }
        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void UserDetails_InvalidManagerId_ReturnsBadRequest(int managerId)
        {
            // Arrange
            var expectedSubordinates = GetEmployeeData();
            // Act
            var result = managerController.UserDetails(managerId);
            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
            var badRequestResult = (BadRequestObjectResult)result;
            managerServiceMock.Verify(s => s.GetSubordinatesDetails(managerId), Times.Never);
        }
        [Fact]
        public void UserDetails_NoSubordinatesFound_ReturnsNotFound()
        {
            // Arrange
            int managerId = 1293;
            var emptySubordinates = GetEmployeeData();

            managerServiceMock
                .Setup(s => s.GetSubordinatesDetails(managerId))
                .Returns(emptySubordinates);
            // Act
            var result = managerController.UserDetails(managerId);
            // Assert
            Assert.IsType<OkObjectResult>(result);
            managerServiceMock.Verify(s => s.GetSubordinatesDetails(managerId), Times.Once);
        }

        [Fact]
        public void FetchUser_ReturnsOkResultWithUserDetails()
        {
            // Arrange
            var expectedUserDetails = GetEmployeeData();
            managerServiceMock.Setup(s => s.GetUserDetails()).Returns(expectedUserDetails);
            // Act
            var result = managerController.FetchUser();
            // Assert
            Assert.IsType<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.Equal(expectedUserDetails, okResult.Value);
            managerServiceMock.Verify(s => s.GetUserDetails(), Times.Once);
        }
        [Fact]
        public void FetchUser_ReturnsOkResultWithEmptyUserDetails()
        {
            // Arrange
            var emptyUserDetails = GetEmployeeData();
            managerServiceMock
                .Setup(s => s.GetUserDetails())
                .Returns(emptyUserDetails);
            // Act
            var result = managerController.FetchUser();
            // Assert
            Assert.IsType<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.Equal(emptyUserDetails, okResult.Value);
            managerServiceMock.Verify(s => s.GetUserDetails(), Times.Once);
        }
        [Fact]
        public void GetUserById_ValidId_ReturnsOkResultWithUserDetails()
        {
            // Arrange
            var expectedUserDetails = GetEmployeeData();
            var expectedUser = expectedUserDetails[1];
            var validId = 1;
            managerServiceMock
                .Setup(s => s.FetchUserById(validId))
                .Returns(new List<AdminViewDto> { expectedUser }.AsQueryable());
            // Act
            var result = managerController.GetUserById(validId);
            // Assert
            Assert.IsType<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            var actualUser = (IEnumerable<AdminViewDto>)okResult.Value;
            var actualUserDetails = actualUser.FirstOrDefault();
            Assert.Equal(expectedUser.Address, actualUserDetails.Address);
            Assert.Equal(expectedUser.Date_of_Birth, actualUserDetails.Date_of_Birth);
            Assert.Equal(expectedUser.Ddesignation, actualUserDetails.Ddesignation);
            Assert.Equal(expectedUser.departmentName, actualUserDetails.departmentName);
            Assert.Equal(expectedUser.Email, actualUserDetails.Email);
            managerServiceMock.Verify(s => s.FetchUserById(validId), Times.Once);
        }
        [Fact]
        public void GetUserById_ValidId_UserNotFound_ReturnsNotFoundResult()
        {
            // Arrange
            int validId = 100;
            AdminViewDto nullUserDetails = null;
            managerServiceMock
                .Setup(s => s.FetchUserById(validId))
                .Returns((IQueryable<object>)nullUserDetails);
            // Act
            var result = managerController.GetUserById(validId);
            // Assert
            Assert.IsType<NotFoundResult>(result);
            managerServiceMock.Verify(s => s.FetchUserById(validId), Times.Once);
        }
        [Theory]
        [InlineData(-1)]
        [InlineData(-2)]
        [InlineData(0)]
        //[InlineData(2)]
        public void GetUserById_InvalidId_ReturnsBadRequestResult(int invalidId)
        {
            // Arrange
            // Act
            var result = managerController.GetUserById(invalidId);
            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
            var badRequestResult = (BadRequestObjectResult)result;
            Assert.Equal("Please input valid Id", badRequestResult.Value);
            managerServiceMock.Verify(s => s.FetchUserById(invalidId), Times.Never);
        }
    }

}