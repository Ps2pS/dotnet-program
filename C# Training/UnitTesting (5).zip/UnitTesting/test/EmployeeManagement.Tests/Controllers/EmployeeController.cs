namespace EmployeeManagement.Tests;
using Xunit;
using EmployeeManagement.Controllers;
using EmployeeManagement.DTO;
using EmployeeManagement.Services;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System;
using AutoFixture;

public class EmployeeControllers : BaseFactoryClass
{
    private readonly Fixture fixture;
    private readonly Mock<IEmployeeService> employeeServiceMock;
    private readonly Mock<IValidator<AdminViewDto>> validatorMock;
    private readonly EmployeeController employeeController;
    public EmployeeControllers()
    {
        fixture = new Fixture();
        employeeServiceMock = new Mock<IEmployeeService>();
        validatorMock = new Mock<IValidator<AdminViewDto>>();
        employeeController = new EmployeeController(employeeServiceMock.Object, validatorMock.Object);
    }
    [Fact]
    public void FetchUser_ReturnsOkResultWithUserDetails()
    {
        // Arrange
        var expectedUserDetails = GetEmployeeData();
        employeeServiceMock.Setup(service => service.GetUserDetails()).Returns(expectedUserDetails.AsQueryable());
        // Act
        var result = employeeController.FetchUser();
        // Assert
        Assert.NotNull(result);
        var okResult = Assert.IsType<OkObjectResult>(result);
        var actualUserDetails = Assert.IsAssignableFrom<IEnumerable<object>>(okResult.Value);
        Assert.Equal(expectedUserDetails.Count, actualUserDetails.Count());
        Assert.Equal(expectedUserDetails, actualUserDetails);
        employeeServiceMock.Verify(x => x.GetUserDetails(), Times.Once());
    }
    [Fact]
    public void FetchUser_ReturnsNotFoundResult_WhenNoUserFound()
    {
        // Arrange
        employeeServiceMock.Setup(service => service.GetUserDetails()).Returns((IQueryable<object>)null);
        // Act
        var result = employeeController.FetchUser();
        // Assert
        Assert.NotNull(result);
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
        employeeServiceMock.Verify(x => x.GetUserDetails(), Times.Once());
    }
    [Fact]
    public void GetUserById_ReturnsOkResult_WhenValidInput()
    {
        var id = fixture.Create<int>();
        var expectedUserDetails = GetEmployeeData();
        try
        {
            if (!expectedUserDetails.Any(user => user.UserId == id))
            {
                throw new Exception($"User with ID {id} not found in GetEmployeeData()");
            }
            employeeServiceMock.Setup(service => service.FetchUserById(id)).Returns(expectedUserDetails.AsQueryable());
            // Act
            var result = employeeController.GetUserById(id);
            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var actualUserDetails = Assert.IsAssignableFrom<IEnumerable<object>>(okResult.Value);
            Assert.Equal(expectedUserDetails.Count(), actualUserDetails.Count());
            Assert.Equal(expectedUserDetails, actualUserDetails);
        }
        catch (Exception ex)
        {
            Assert.Contains($"User with ID {id} not found", ex.Message);
            return;
        }
        Assert.True(false, $"Expected exception was not thrown for user with ID {id}");
        employeeServiceMock.Verify(x => x.FetchUserById(id), Times.Once());
    }
    [Fact]
    public void GetUserById_ReturnsNotFoundResult_WhenNoUserFound()
    {
        // Arrange
        var userId = fixture.Create<int>();
        employeeServiceMock.Setup(service => service.FetchUserById(userId)).Returns((IQueryable<object>)null);
        //Act
        var result = employeeController.GetUserById(userId);
        // Assert
        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
        var errorMessage = Assert.IsType<string>(notFoundResult.Value);
        Assert.Equal("User not found.", errorMessage);
        employeeServiceMock.Verify(x => x.FetchUserById(userId), Times.Once());
    }
    [Theory]
    [InlineData(-1)]
    [InlineData(0)]
    public void GetUserById_InvalidId_ReturnsBadRequestResult(int id)
    {
        // Arrange
        var expectedUserDetails = GetEmployeeData();
        employeeServiceMock.Setup(x => x.FetchUserById(id)).Returns((IQueryable<object>)null);
        // Act
        var result = employeeController.GetUserById(id);
        // Assert
        Assert.IsType<BadRequestResult>(result);
    }

}