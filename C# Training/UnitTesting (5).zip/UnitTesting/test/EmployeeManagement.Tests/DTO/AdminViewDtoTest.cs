using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.DTO;
using Xunit;

namespace EmployeeManagement.Tests.DTO
{
    public class AdminViewDtoTest
    {
         private AdminViewDto? Target { get; set; }

        private Type TargetType { get; set; }
        public AdminViewDtoTest()
        {
            this.Target = null;

            this.TargetType = typeof(AdminViewDto);
        }
        [Fact]
        public void ItShouldBeClass()
        {
            Assert.True(this.TargetType.IsClass);
        }
    }
}