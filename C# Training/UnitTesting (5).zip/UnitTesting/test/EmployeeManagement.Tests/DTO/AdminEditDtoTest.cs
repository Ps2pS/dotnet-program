using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.DTO;
using Xunit;

namespace EmployeeManagement.Tests.DTO
{
    public class AdminEditDtoTest
    {
         private AdminEditDto? Target { get; set; }

        private Type TargetType { get; set; }
        public AdminEditDtoTest()
        {
            this.Target = null;

            this.TargetType = typeof(AdminEditDto);
        }
        [Fact]
        public void ItShouldBeClass()
        {
            Assert.True(this.TargetType.IsClass);
        }
    }
}