using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.DTO;
using Xunit;

namespace EmployeeManagement.Tests.DTO
{
    public class UserProfessionalDetailDtoTest
    {
        private UserProfessionalDetailDto? Target { get; set; }

        private Type TargetType { get; set; }
        public UserProfessionalDetailDtoTest()
        {
            this.Target = null;

            this.TargetType = typeof(UserProfessionalDetailDto);
        }
        [Fact]
        public void ItShouldBeClass()
        {
            Assert.True(this.TargetType.IsClass);
        }
    }
}