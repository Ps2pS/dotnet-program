// using System.Collections;
// using AutoFixture;
// using EmployeeManagement.Context;
// using EmployeeManagement.Models;
// using EmployeeManagement.Services;
// using Microsoft.EntityFrameworkCore;
// using Moq;

// namespace EmployeeManagement.Tests.Services
// {
// public class ManagerServiceTests:BaseFactoryClass
// {
//     [Fact]
//     public void GetSubordinatesDetails_ReturnsSubordinatesWithDetails()
//     {
//         // Arrange
//         var fixture = new Fixture();
//         var managerId = 1;
//         var expectedSubordinates =  GetEmployeeData();
//         var userDbContextMock = new Mock<UserDBContext>();
//         // Set up the UserDbContext mock to return the expected subordinates
//         userDbContextMock.Setup(db => db.Users).Returns(MockUsersDbSet(expectedSubordinates));
//         var managerService = new ManagerService(userDbContextMock.Object);
//         // Act
//         var result = managerService.GetSubordinatesDetails(managerId);
//         // Assert
//       Assert.NotNull(result);
// Assert.IsAssignableFrom<IEnumerable>(result);  // Ensure result is a collection
// Assert.Equal(expectedSubordinates.Count(), ((IEnumerable)result).Cast<object>().Count());
//     }

//     private DbSet<User> MockUsersDbSet(IEnumerable<object> expectedSubordinates)
//     {
//         var usersDbSetMock = new Mock<DbSet<User>>();
//         var queryableSubordinates = expectedSubordinates.AsQueryable();

//         usersDbSetMock.As<IQueryable<User>>().Setup(m => m.Provider).Returns(queryableSubordinates.Provider);
//         usersDbSetMock.As<IQueryable<User>>().Setup(m => m.Expression).Returns(queryableSubordinates.Expression);
//         usersDbSetMock.As<IQueryable<User>>().Setup(m => m.ElementType).Returns(queryableSubordinates.ElementType);
//         usersDbSetMock.As<IQueryable<User>>().Setup(m => m.GetEnumerator()).Returns((IEnumerator<User>)queryableSubordinates.GetEnumerator());

//         return usersDbSetMock.Object;
//     }
// }
 
// }