using System.ComponentModel.DataAnnotations;
using EmployeeManagement.Models;
namespace EmployeeManagement.Tests.Models
{
    public class UserTest
    {
        private User? Target { get; set; }

        private Type TargetType { get; set; }
        public UserTest()
        {
            this.Target = null;

            this.TargetType = typeof(User);
        }
        [Fact]
        public void ItShouldBeClass()

        {

            Assert.True(this.TargetType.IsClass);

        }
        [Fact]
        public void UserId_Property_HasKeyAttribute()
        {
            // Arrange
            var property = typeof(User).GetProperty("UserId");

            // Act
            var hasKeyAttribute = property.GetCustomAttributes(typeof(KeyAttribute), true).Length > 0;

            // Assert
            Assert.True(hasKeyAttribute);
        }
        [Fact]
        public void Email_Property_CanNotBeNull()
        {
            // Arrange
            var property = typeof(User).GetProperty("Email");

            // Act
            var allowNotNull = property.GetCustomAttributes(typeof(RequiredAttribute), true).Length > 0;

            // Assert
            Assert.True(allowNotNull);
        }
        [Fact]
        public void Password_Property_CanNotBeNull()
        {
            // Arrange
            var property = typeof(User).GetProperty("Password");
            // Act
            var allowNotNull = property.GetCustomAttributes(typeof(RequiredAttribute), true).Length > 0;
            // Assert
            Assert.True(allowNotNull);
        }

    }
}