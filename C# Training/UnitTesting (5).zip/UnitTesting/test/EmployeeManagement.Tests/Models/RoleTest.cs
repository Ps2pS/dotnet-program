using EmployeeManagement.Models;
namespace EmployeeManagement.Tests.Models
{
    public class RoleTest
    {
        private Role? Target { get; set; }

        private Type TargetType { get; set; }
        public RoleTest()
        {
            this.Target = null;

            this.TargetType = typeof(Role);
        }
        [Fact]
        public void ItShouldBeClass()
        {
            Assert.True(this.TargetType.IsClass);
        }
    }
}