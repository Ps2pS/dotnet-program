using System.ComponentModel.DataAnnotations;
using EmployeeManagement.Models;
namespace EmployeeManagement.Tests.Models
{
    public class AcademicsTest
    {
        private AcademicInfo? Target { get; set; }

        private Type TargetType { get; set; }
        public AcademicsTest()
        {
            this.Target = null;

            this.TargetType = typeof(AcademicInfo);
        }
        [Fact]
        public void ItShouldBeClass()
        {
            Assert.True(this.TargetType.IsClass);
        }
        [Fact]
        public void AcademicId_Property_HasKeyAttribute()
        {
            // Arrange
            var property = typeof(AcademicInfo).GetProperty("Id");

            // Act
            var hasKeyAttribute = property.GetCustomAttributes(typeof(KeyAttribute), true).Length > 0;

            // Assert
            Assert.True(hasKeyAttribute);
        }
    }
}