using System.ComponentModel.DataAnnotations;
using EmployeeManagement.Models;
namespace EmployeeManagement.Tests.Models
{
    public class ProfessionalTest
    {
        private ProfessionalInfo? Target { get; set; }

        private Type TargetType { get; set; }
        public ProfessionalTest()
        {
            this.Target = null;

            this.TargetType = typeof(ProfessionalInfo);
        }
        [Fact]
        public void ItShouldBeClass()
        {
            Assert.True(this.TargetType.IsClass);
        }
        [Fact]
        public void ProfessionalId_Property_HasKeyAttribute()
        {
            // Arrange
            var property = typeof(ProfessionalInfo).GetProperty("ProfessionalId");

            // Act
            var hasKeyAttribute = property.GetCustomAttributes(typeof(KeyAttribute), true).Length > 0;

            // Assert
            Assert.True(hasKeyAttribute);
        }
    }
}