using System.ComponentModel.DataAnnotations;
using EmployeeManagement.Models;
namespace EmployeeManagement.Tests.Models
{
    public class DepartmentTest
    {
        private Department? Target { get; set; }

        private Type TargetType { get; set; }
        public DepartmentTest()
        {
            this.Target = null;

            this.TargetType = typeof(Department);
        }
        [Fact]
        public void ItShouldBeClass()
        {
            Assert.True(this.TargetType.IsClass);
        }
        [Fact]
        public void DepartmentId_Property_HasKeyAttribute()
        {
            // Arrange
            var property = typeof(Department).GetProperty("DeptId");

            // Act
            var hasKeyAttribute = property.GetCustomAttributes(typeof(KeyAttribute), true).Length > 0;

            // Assert
            Assert.True(hasKeyAttribute);
        }
    }
}