using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.Services;
using Xunit;

namespace EmployeeManagement.Tests.Interface
{
    public class IEmployeeServiceTest
    {
        private IEmployeeService? Target { get; set; }
        private Type TargetType { get; set; }
        public IEmployeeServiceTest()
        {
            this.Target = null;
            this.TargetType = typeof(IManagerService);
        }
        [Fact]
        public void ItShouldBeInterface()
        {
            Assert.True(this.TargetType.IsInterface);
        }
    }
}