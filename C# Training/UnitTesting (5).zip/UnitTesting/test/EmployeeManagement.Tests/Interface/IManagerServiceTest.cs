using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.Services;
using Xunit;

namespace EmployeeManagement.Tests.Interface
{
    public class IManagerServiceTest
    { 
        private IManagerService? Target { get; set; }
        private Type TargetType { get; set; }
        public IManagerServiceTest()
        {
            this.Target = null;
            this.TargetType = typeof(IManagerService);
        }
        [Fact]
        public void ItShouldBeInterface()
        {
            Assert.True(this.TargetType.IsInterface);
        }
    }
}