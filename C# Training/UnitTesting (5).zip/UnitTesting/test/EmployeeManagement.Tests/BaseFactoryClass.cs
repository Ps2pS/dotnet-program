using AutoFixture;
using EmployeeManagement.DTO;

namespace EmployeeManagement.Tests
{
    public class BaseFactoryClass : DateOnlyBuilder
    {
        private readonly Fixture fixture;
        public BaseFactoryClass()
        {
            fixture = new Fixture();
            fixture.Customizations.Add(new DateOnlyBuilder());
        }
        public List<AdminViewDto> GetEmployeeData()
        {
            var adminViewDtoList = fixture.Build<AdminViewDto>()
                .With(x => x.Date_of_Birth, new DateOnly(1990, 1, 1)) // Provide valid Date_of_Birth values
                .With(x => x.JoinDate, new DateOnly(1990, 1, 1))
                .With(x => x.LastDate, new DateOnly(1990, 1, 1))
                .CreateMany(5)
                .ToList();
            return adminViewDtoList;
        }
        public AdminViewDto CreateEmployeeData()
        {
            var fixture = new Fixture();
            fixture.Customizations.Add(new DateOnlyBuilder());
            var adminViewDtoList = fixture.Create<AdminViewDto>();
            return adminViewDtoList;
        }
        // private List<AdminViewDto> GetEmployeesData()
        // {
        //     var adminViewDto = new AdminViewDto
        //     {
        //         UserId = 3,
        //         FirstName = "Ravi",
        //         LastName = "Singh",
        //         Email = "ravi@gmail.com",
        //         PhoneNumber = "8888888888",
        //         Date_of_Birth = new DateOnly(2023, 5, 1),
        //         Address = "Delhi",
        //         Password = "Ravi1234",
        //         ManagerId = 2,
        //         isActive = true,
        //         userProfessional = new List<UserProfessionalDetailDto>
        //             {

        //                 new UserProfessionalDetailDto
        //                 {
        //                     ProfessionalId = 3,
        //                     CompanyName = "taaazaaaatech",
        //                     Designation = "ASET",
        //                     //StartDate = new DateOnly(2023, 5, 2),
        //                     //EndDate = new DateOnly(2023, 5, 3),
        //                 }
        //             },
        //         userAcademics = new List<UserAcademicDto>
        //             {
        //                 new UserAcademicDto
        //                 {
        //                     Id = 4,
        //                     Qualification = "Mca",
        //                     Year = 2022,
        //                     College = "JIMS",
        //                     Place = "DELHI"
        //                 }
        //             },
        //         departmentName = "engineer",
        //         Ddesignation = "ASET",
        //         JoinDate = new DateOnly(2023, 5, 10),
        //         LastDate = new DateOnly(2023, 5, 10),
        //         RoleId = 2
        //     };
        //     var adminViewDto2 = new AdminViewDto
        //     {
        //         UserId = 4,
        //         FirstName = "Ravi",
        //         LastName = "Singh",
        //         Email = "ravi@gmail.com",
        //         PhoneNumber = "8888888888",
        //         Date_of_Birth = new DateOnly(2023, 5, 1),
        //         Address = "Delhi",
        //         Password = "Ravi1234",
        //         ManagerId = 2,
        //         isActive = true,
        //         userProfessional = new List<UserProfessionalDetailDto>
        //             {

        //                 new UserProfessionalDetailDto
        //                 {
        //                     ProfessionalId = 3,
        //                     CompanyName = "taaazaaaatech",
        //                     Designation = "ASET",
        //                    // StartDate = new DateOnly(2023, 5, 2),
        //                     //EndDate = new DateOnly(2023, 5, 3),
        //                 }
        //             },
        //         userAcademics = new List<UserAcademicDto>
        //             {
        //                 new UserAcademicDto
        //                 {
        //                     Id = 4,
        //                     Qualification = "Mca",
        //                     Year = 2022,
        //                     College = "JIMS",
        //                     Place = "DELHI"
        //                 }
        //             },
        //         departmentName = "engineer",
        //         Ddesignation = "ASET",
        //         JoinDate = new DateOnly(2023, 5, 10),
        //         LastDate = new DateOnly(2023, 5, 10),
        //         RoleId = 2
        //     };
        //     var adminViewDto3 = new AdminViewDto
        //     {
        //         UserId = 5,
        //         FirstName = "Ravi",
        //         LastName = "Singh",
        //         Email = "ravi@gmail.com",
        //         PhoneNumber = "8888888888",
        //         Date_of_Birth = new DateOnly(2023, 5, 1),
        //         Address = "Delhi",
        //         Password = "Ravi1234",
        //         ManagerId = 2,
        //         isActive = true,
        //         userProfessional = new List<UserProfessionalDetailDto>
        //             {

        //                 new UserProfessionalDetailDto
        //                 {
        //                     ProfessionalId = 3,
        //                     CompanyName = "taaazaaaatech",
        //                     Designation = "ASET",
        //                     //StartDate = new DateOnly(2023, 5, 2),
        //                   //  EndDate = new DateOnly(2023, 5, 3),
        //                 }
        //             },
        //         userAcademics = new List<UserAcademicDto>
        //             {
        //                 new UserAcademicDto
        //                 {
        //                     Id = 4,
        //                     Qualification = "Mca",
        //                     Year = 2022,
        //                     College = "JIMS",
        //                     Place = "DELHI"
        //                 }
        //             },
        //         departmentName = "engineer",
        //         Ddesignation = "ASET",
        //         JoinDate = new DateOnly(2023, 5, 10),
        //         LastDate = new DateOnly(2023, 5, 10),
        //         RoleId = 2
        //     };
        //     var adminViewDtoList = new List<AdminViewDto>();
        //     adminViewDtoList.Add(adminViewDto);
        //     adminViewDtoList.Add(adminViewDto2);
        //     adminViewDtoList.Add(adminViewDto3);
        //     return adminViewDtoList;

        // }


    }
}