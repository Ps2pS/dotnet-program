using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using oneTooneService.Models.Entity;
using oneTooneService.ViewModel.DTO;

namespace oneTooneService.Functionality
{
    public interface IUserService
    {
       int CreateUser (UserViewModel userViewModel);
       List<User> GetUserDetails();
    }
}