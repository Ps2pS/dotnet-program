using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using oneTooneService.ViewModel.DTO;
using oneTooneService.Database;
using oneTooneService.Models.Entity;
using Microsoft.EntityFrameworkCore;


namespace oneTooneService.Functionality
{
    public class UserService : IUserService
    {
        UserDBContext userDBContext;
        public UserService(UserDBContext _userDbContext) //DI
        {
            userDBContext = _userDbContext;
        }
        int IUserService.CreateUser(UserViewModel userViewModel)
        {
            int Id=0;
           //UserViewModel....1.User....2.Userprofile
           User objUser = new User();
           objUser.UserName= userViewModel.UserName;
           objUser.Email= userViewModel.Email;
           objUser.AddedDate= userViewModel.AddedDate;
           objUser.IPAddress= userViewModel.IPAddress;
           objUser.Password= userViewModel.Password;
           objUser.ModifiedDate = userViewModel.ModifiedDate;

           userDBContext.users.Add(objUser);
           userDBContext.SaveChanges();//commit to database
           Id = Convert.ToInt32(objUser.Id);


           objUser.userProfile=new UserProfile();
           objUser.userProfile.FirstName= userViewModel.FirstName;
           objUser.userProfile.LastName= userViewModel.LastName;
           objUser.userProfile.Address= userViewModel.Address;
           objUser.userProfile.IPAddress= userViewModel.IPAddress;
           objUser.userProfile.AddedDate= userViewModel.AddedDate;
           objUser.userProfile.ModifiedDate= userViewModel.ModifiedDate;
           

           userDBContext.usersprofile.Add(objUser.userProfile);
           objUser.userProfile.Id=Id;
         return userDBContext.SaveChanges();
        }

        List<User> IUserService.GetUserDetails()
        {
          var Userlist = userDBContext.users.Include(d=>d.userProfile).ToList();
         // var Userlist = userDbContext.users.ToList();
            return Userlist;
        }
    }
}