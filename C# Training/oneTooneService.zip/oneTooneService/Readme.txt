Case study:-
OneToOne Relationship in dotnet core 5.0 and 6.0

Applying code first approach to visulize the whole process and implementing major design pattern
1.Clean Architecture.
2.Fluent-API pattern.
3.Fluent Model Validation pattern.
4.Navigation Principle.

Remark- Trying to achieve SOLID PRINCIPLE.


Can you explain the folder structure of your application.

1. Database-applying ef core with code first approach.
2. Functionality-similar to Service Layer or BLL or Repository
3. Models
  a- Entity
  b- EntityMapper ---apply fluent api here
4. ViewModel
  a- DTO- Extracting multiple properties from different model classes to post data. 
  b- DTOValidation - apply fluent model validation.
  c- Implementing Fluent model relation
  dotnet add package FluentValidation.AspNetCore
5. DynamicMigration- Need to write the logic to generate the database dynamically  


19 March 23- Session 2

Agenda-

1. Need to apply Fluent API for relationship.(EntityMapper Folder....)
2. We have to define the EF CORE (Database folder....)
3. When we will define EF CORE - 2 CLASSES plays a major role-
     a. DbContext(DML, Design pattern for transaction(Unit of work))
     b. DbSet(LINQ for search etc... Eager loading(Include()function, Theninclude()) or lazy loading (increase round trips))


     fluent api-
     

     public UserMap(EntityTypeBuilder<User> entityBuilder)
     {
      entityBuilder.HasKey(t => t.Id);
      entityBuilder.Property(t => t.UserName).IsRequired();
      entityBuilder.Property(t => t.Password).IsRequired();
      entityBuilder.Property(t => t.Email).IsRequired();
     }


     Part 1-
     -Define EFCore

     Part2-
     -Define ServiceLayer(Business Logic or Functionality or Repository)

     Part3-
     -controller

     Part4-
     -Think for Enhancement(One to Many,Exception Handling,Security,AutoMapper,Middleware,Extension Method)

     --No Fluent Model validation, No any functions for joins



Package-
dotnet add package Microsoft.AspNetCore.Mvc.NewtonsoftJson