
using Microsoft.AspNetCore.Mvc;
using oneTooneService.Functionality;
using oneTooneService.ViewModel.DTO;
using FluentValidation;
using FluentValidation.Results;

namespace oneTooneService.Controllers
{
    [Route("[controller]")]
    public class UserController: ControllerBase
    {

        private IValidator<UserViewModel> validator;
        //Applying DI 
        IUserService iuserservice;
        public UserController(IUserService _iuserservice,IValidator<UserViewModel> _validator)
        {
            validator=_validator;
            iuserservice = _iuserservice;
         
        }

            [HttpPost("CreateUser")]

            public IActionResult UserCreate([FromBody] UserViewModel viewModel)
            {
                ValidationResult result=validator.Validate(viewModel);
                if(result.IsValid)
                {
                    return Ok(iuserservice.CreateUser(viewModel));
                }
                else
                {
                    return BadRequest(result.Errors);
                }
              
            }
            
            [HttpGet("details")]
            public IActionResult UserDetails()
            {
                return Ok(iuserservice.GetUserDetails());
            }
    }
}