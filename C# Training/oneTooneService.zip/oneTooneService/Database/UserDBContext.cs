using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using oneTooneService.Models.Entity;
using oneTooneService.Models.EntityMapper;

namespace oneTooneService.Database
{
    public class UserDBContext : DbContext
    {
        public UserDBContext(DbContextOptions dbContextOptions) : base(dbContextOptions)
        {


        }
        public DbSet<User> users { get; set; }

        public DbSet<UserProfile> usersprofile { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Apply Association with User....UserMapper

            //Apply Association with UserProfile....UserProfileMapper
            new UserMapper(modelBuilder.Entity<User>());

            new UserProfileMapper(modelBuilder.Entity<UserProfile>());

            modelBuilder.Entity<User>().HasData(
               new User
               {
                   Id = 101,
                   UserName = "Pragya",
                   Email = "Singh.pragya@gmail.com",
                   IPAddress = "198.00.124",
                   Password = "1524@Pra",
                   AddedDate = new DateTime(2016, 5, 16, 13, 45, 0),
                   ModifiedDate = new DateTime(2016, 6, 14, 16, 50, 0)

               }
            );
            modelBuilder.Entity<UserProfile>().HasData(
               new UserProfile
               {
                   Id = 101,
                   FirstName="Pragya",
                   LastName="Singh",
                   Address="Noida",
                    AddedDate = new DateTime(2016, 5, 16, 13, 45, 0),
                   ModifiedDate = new DateTime(2016, 6, 14, 16, 50, 0),
                   IPAddress = "198.00.124"


               }
            );  
          }
    }
}