﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace oneTooneService.Migrations
{
    public partial class phase3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "users",
                columns: new[] { "Id", "AddedDate", "Email", "IPAddress", "ModifiedDate", "Password", "UserName" },
                values: new object[] { 101L, new DateTime(2016, 5, 16, 13, 45, 0, 0, DateTimeKind.Unspecified), "Singh.pragya@gmail.com", "198.00.124", new DateTime(2016, 6, 14, 16, 50, 0, 0, DateTimeKind.Unspecified), "1524@Pra", "Pragya" });

            migrationBuilder.InsertData(
                table: "usersprofile",
                columns: new[] { "Id", "AddedDate", "Address", "FirstName", "IPAddress", "LastName", "ModifiedDate" },
                values: new object[] { 101L, new DateTime(2016, 5, 16, 13, 45, 0, 0, DateTimeKind.Unspecified), "Noida", "Pragya", "198.00.124", "Singh", new DateTime(2016, 6, 14, 16, 50, 0, 0, DateTimeKind.Unspecified) });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "usersprofile",
                keyColumn: "Id",
                keyValue: 101L);

            migrationBuilder.DeleteData(
                table: "users",
                keyColumn: "Id",
                keyValue: 101L);
        }
    }
}
