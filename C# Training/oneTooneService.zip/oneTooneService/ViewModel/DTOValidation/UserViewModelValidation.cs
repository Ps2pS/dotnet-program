using System;
using FluentValidation;
using oneTooneService.ViewModel.DTO;
namespace oneTooneService.ViewModel.DTOValidation
{
    public class UserViewModelValidation : AbstractValidator<UserViewModel>
    {
        public UserViewModelValidation()
        {
            RuleFor(x => x.UserName).NotEmpty().WithMessage("UserName should not left blank");
            RuleFor(x => x.FirstName).NotEmpty();
            RuleFor(x => x.LastName).NotEmpty();
            RuleFor(x => x.Address).NotEmpty();
            RuleFor(x => x.Email).EmailAddress();
           
        }
    }
}