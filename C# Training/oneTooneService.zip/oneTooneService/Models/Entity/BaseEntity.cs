using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace oneTooneService.Models.Entity
{
    public abstract class BaseEntity //taking common properties here from multple classes
    {
        public Int64 Id{get; set;}

        public DateTime AddedDate{get; set;}

        public DateTime ModifiedDate{get; set;}

        public string IPAddress{get; set;}
    }
}