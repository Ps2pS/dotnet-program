using System;
using Microsoft.EntityFrameworkCore.Metadata.Builders; // for Fluent API
using oneTooneService.Models.Entity;



namespace oneTooneService.Models.EntityMapper
{ //Fluent API for user profile table.
    public class UserMapper
    {
        //EntityTypeBuilder- to apply 
       public UserMapper(EntityTypeBuilder<User> entityTypeBuilder)
       {
        //Fluent API

            entityTypeBuilder.HasKey(t => t.Id);
            entityTypeBuilder.Property(t => t.UserName).IsRequired();
            entityTypeBuilder.Property(t => t.Password).IsRequired();
            entityTypeBuilder.Property(t => t.Email).IsRequired(); 
            //Define Primary key & Foreign Key
        entityTypeBuilder.HasOne(t => t.userProfile).WithOne(u => u.user).HasForeignKey<UserProfile>(x => x.Id);
       
       }
    }
}