using System;
using Microsoft.EntityFrameworkCore.Metadata.Builders; // for Fluent API

namespace oneTooneService.Models.EntityMapper
{
    public class UserProfileMapper
    {
        public UserProfileMapper(EntityTypeBuilder<Entity.UserProfile> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(t => t.Id);
            entityTypeBuilder.Property(t => t.FirstName).IsRequired();
            entityTypeBuilder.Property(t => t.LastName).IsRequired();
            entityTypeBuilder.Property(t => t.Address);
        }
    }
}