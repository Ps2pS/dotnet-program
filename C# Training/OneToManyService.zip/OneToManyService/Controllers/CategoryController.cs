using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OneToManyService.Models;

namespace OneToManyService.Controllers
{
      [Route("api/[controller]")]
    public class CategoryController : ControlerBase
    {
       private readonly AppDbContext appDbContext;

       public CategoryController(AppDbContext _appDbContext)
       {
          appDbContext = _appDbContext;
       }

      [HttpGet]
       public async Task<ActionResult<List<Category>>> Get()
       {
         var categories = await appDbContext.Categories.Include(c=>c.Posts).ToListAsync();
         return categories;

       }
    }
}