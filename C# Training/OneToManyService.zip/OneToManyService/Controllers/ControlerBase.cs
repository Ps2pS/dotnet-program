namespace OneToManyService.Controllers
{
    public class ControlerBase
    {
    }
}