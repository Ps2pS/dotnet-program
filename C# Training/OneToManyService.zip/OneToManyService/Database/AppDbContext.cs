using System;
using Microsoft.EntityFrameworkCore;
using OneToMany.Models.Mapper;
using OneToManyService.Models;
using OneToManyService.Models.Mapper;

namespace OneToManyService.Controllers
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
         
        }

         protected override void OnModelCreating (ModelBuilder modelBuilder)
         {
             new CategoryMapper(modelBuilder.Entity<Category>());

            new PostMapper(modelBuilder.Entity<Post>());

              //Applying seeds
            modelBuilder.Entity<Category>().HasData(
               new Category
               {
                  Id=101,
                 Name="Alex",
                
               }
            );
            modelBuilder.Entity<Post>().HasData(
                new Post
                {
                   PostId=102,
                   Title="Karma",
                   Description="Karma is Back",
                   CategoryId=101,
                 

                }
            );
         }
           public DbSet<Category> Categories {get; set;}

           public DbSet<Post> Posts {get; set;}

          
    }
}