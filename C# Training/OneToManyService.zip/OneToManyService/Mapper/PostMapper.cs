using System;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OneToMany.Models;
using OneToManyService.Models;

namespace OneToMany.Models.Mapper
{
    public class PostMapper
    {
        public PostMapper(EntityTypeBuilder<Post> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(t => t.CategoryId);
            entityTypeBuilder.Property(t => t.PostId).IsRequired();
            entityTypeBuilder.Property(t => t.Description).IsRequired(); 
            entityTypeBuilder.Property(t => t.Title).IsRequired();    
            entityTypeBuilder.HasOne(c => c.Category).WithMany(p=>p.Posts).HasForeignKey(u=>u.CategoryId);
        }
    }
}