using System;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OneToManyService.Models;
using OneToManyService.Models.Mapper;

namespace OneToManyService.Models.Mapper
{
    public class CategoryMapper
    {
        public CategoryMapper(EntityTypeBuilder<Category> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(t => t.Id);
            entityTypeBuilder.Property(t => t.Name).IsRequired();
            

                    
        }
        }
       
    }
