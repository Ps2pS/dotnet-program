using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Crud_ProjectBE.Models
{
    public class Patient
    {
        [Key]
        public int PatientId{get;set;}
        public string PatientName{get;set;}
        public  string Password{get;set;}
        public int Age{get;set;}
        public long Phone_No{get;set;}
    }
    public class PatientLogin{
        public string PatientName{get;set;}
        public  string Password{get;set;}
    }
}