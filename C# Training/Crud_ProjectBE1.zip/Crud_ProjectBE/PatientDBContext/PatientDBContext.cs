using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Crud_ProjectBE.Models;

namespace Crud_ProjectBE.PatientDBContext1
{
        public class PatientDBContext:DbContext
        {
             public PatientDBContext(DbContextOptions dbContextOptions) : base(dbContextOptions)
        {

        }
            public DbSet<Patient> patients{get;set;}
            
    }
}