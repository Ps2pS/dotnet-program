using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Crud_ProjectBE.Models;

namespace Crud_ProjectBE.Functionality
{
    public interface IPatientService
    {
         public int CreatePatient(Patient patient);
        List<Patient> GetPatientDetails();
        Patient GetPatientSingleData(int id);
        int DeleteUserSingleData(int id);
    }
}