using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Crud_ProjectBE.Models;
using Crud_ProjectBE.PatientDBContext1;

namespace Crud_ProjectBE.Functionality
{
    
    public class PatientService : IPatientService
    {
        PatientDBContext PatientDBContext;
        public PatientService(PatientDBContext _PatientDBContext){
            PatientDBContext=_PatientDBContext;
        }
        public int CreatePatient(Patient patient)
        {
            PatientDBContext.patients.Add(patient);
            return PatientDBContext.SaveChanges();
        }

        public List<Patient> GetPatientDetails()
        {
        var patientlist=PatientDBContext.patients.ToList();
        return patientlist;

        }

        public Patient GetPatientSingleData(int id)
        {
            Patient patientV=new Patient();
              patientV=PatientDBContext.patients . SingleOrDefault(t=>t.PatientId ==id);
              return patientV;
        }

        public int DeleteUserSingleData(int id)
        {
             Patient PatientV=new Patient();
              PatientV=PatientDBContext.patients.SingleOrDefault(t=>t.PatientId==id);
              if(PatientV==null){
                return 0;
              }else{
                PatientDBContext.patients.Remove(PatientV);
                return PatientDBContext.SaveChanges();
              }
        }
    }
}