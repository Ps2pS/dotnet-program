using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Crud_ProjectBE.Functionality;
using Crud_ProjectBE.PatientDBContext1;
using Crud_ProjectBE.Models;

namespace Crud_ProjectBE.Controllers
{
    [Route("[controller]")]
    public class PatientController : Controller
    {
        IPatientService ipatientService;
        public PatientController(IPatientService _ipatientService)
        {
            ipatientService=_ipatientService;
        }
      
        [HttpPost("CreatePatient")]
        public IActionResult CreateUserResult([FromBody] Patient patient)
        {return Ok(ipatientService.CreatePatient(patient));
        }
        [HttpGet("getPatientdata")]
                public IActionResult GetUserData(){
            return Ok(ipatientService.GetPatientDetails());
        }

        [HttpGet("GetPatientSingleData")]
        public IActionResult GetUserSingleRecord(int id){
            if(id==null){
                return BadRequest();
            }else{
            return Ok(ipatientService.GetPatientSingleData(id));
            }

        }
        [HttpPost("DeletePatientSingleData")]
        public IActionResult DeleteUserData(int id){
             if(id==null){
                return BadRequest();
            }else{
            return Ok(ipatientService.DeleteUserSingleData(id));
            }
        }
    }
}